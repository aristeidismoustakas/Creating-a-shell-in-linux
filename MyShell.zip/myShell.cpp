#include <iostream>
#include <unistd.h>
#include <vector>
#include <string.h>
#include <sys/types.h>
#include <cstring>
#include <stdio.h>
#include <signal.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <algorithm>
#include <functional>
#include <fcntl.h>

using namespace std;
static vector<pid_t> pidlist;
static struct itimerval itv;
void signal_handler(int signum)
{
    if (signum==9 || signum==SIGINT)
    {
        kill(0,SIGKILL);
        exit(0);
    }
}
void time_stopper()
{
    itv.it_value.tv_sec =  0;
    itv.it_interval.tv_sec =  0;
    if (setitimer(ITIMER_REAL, &itv, NULL) == -1)
        perror("setitimer");


}
void timer_handler (int signum)
{

    int status;
    status=waitpid(pidlist.at(pidlist.size()-1),NULL,WNOHANG);
    if (status==0)
    {
        kill(pidlist.at(pidlist.size()-1),SIGSTOP);
        pid_t current = pidlist.at(0);
        kill(current,SIGCONT);
        pidlist.erase(pidlist.begin());
        pidlist.push_back(current);
    }
    else
    {
        cout<<"pid "<<pidlist.at(pidlist.size()-1)<<" terminated"<<endl;
        pidlist.erase(pidlist.end()-1,pidlist.end());
        if (pidlist.size()==0) time_stopper();
        else
        {
            pid_t current = pidlist.at(0);
            kill(current,SIGCONT);
            pidlist.push_back(current);
            pidlist.erase(pidlist.begin());
        }
    }
}
void start_timer()
{

    /* Set timer  */

    itv.it_value.tv_sec =  1;
    itv.it_interval.tv_sec =  1;

    if (setitimer(ITIMER_REAL, &itv, NULL) == -1) perror("setitimer");
    signal(SIGALRM,&timer_handler);
}
std::string trim(std::string str)
{
    size_t first = str.find_first_not_of(' ');
    size_t last = str.find_last_not_of(' ');
    if(first == std::string::npos || last == std::string::npos) return "";
    return str.substr(first, (last-first+1));
}

std::vector<std::string> getTokens(std::string command)
{
    bool squote, dquote, escape, foundChar, done;

    //int temp = 0;

    std::string token;
    std::vector<std::string> tokens;

    while(!done)
    {

        squote = false;
        dquote = false;
        escape = false;
        foundChar = false;

        size_t i = 0;
        token = "";

        for(i = 0; i<command.size(); i++)
        {
            if(command[i] == '|' || command[i] == '<') {
                if(!squote && !dquote && foundChar) {
                    if(i+1 < command.size() && command[i+1] != ' ') command.insert(i+1," ");
                    break;
                }
            }

            else if(command[i] == '>') {
                if(!squote && !dquote && foundChar) {
                    if(i+1 < command.size() && command[i+1] != ' ') {
                        if(command[i+1] == '>' && i+2 < command.size()) command.insert(i+2," ");
                        else if(command[i+1] != '>') command.insert(i+1," ");
                        break;
                    }
                }
            }

            token += command[i];

            if(command[i] == ' ')
            {
                if(!squote && !dquote && foundChar) break;
                escape = false;
            }

            else if(command[i] == '\'')
            {
                if(!escape)
                {
                    squote = !squote;
                }
                else escape = false;
            }

            else if(command[i] == '"')
            {
                if(!escape)
                {
                    dquote = !dquote;
                }
                else escape = false;
            }

            else if(command[i] == '\\')
            {
                escape = !escape;
            }

            else
            {
                escape = false;
                foundChar = true;
            }

        }
        command.erase(0,token.size());
        if(command.size() == 0) done = true;
        token = trim(token);

        if(token[0] == '\'' && token[token.size() -1] == '\'' && token.size() >= 2) {
            token = token.substr(1,token.size() -2);
        }
        if(token[0] == '"' && token[token.size() -1] == '"' && token.size() >= 2) {
            token = token.substr(1,token.size() -2);
        }
        tokens.push_back(token);
    }
    return tokens;
}




void forkAndExecute(std::vector<std::string> &tokens, bool background)
{
    char * argv[tokens.size()+1];
    argv[tokens.size()]=NULL;
    for (std::size_t i = 0; i < tokens.size(); ++i)
    {
        argv[i] = &tokens[i][0];
    }
    pid_t id = fork();
    if(background)
    {
        argv[tokens.size()-1]=NULL; // σβήνει το & από την τελευταία θέση
    }
    if(id == 0)
    {
        int res=execvp(argv[0],argv);
        if(res == -1) perror("shell");
    }
    else
    {
        if(id > 0)
        {
            int status;
            if(!background)
            {
                waitpid(id, &status, 0);
            }
            else
            {
                kill(id,SIGSTOP);
                if (pidlist.empty())
                {
                    start_timer();
                }
                pidlist.push_back(id);
            }
        }
        else
        {
            cout<<"Fork() error"<<endl;
        }
    }

}


size_t findToken(std::vector<std::string> tokens, std::string token)
{
    for(size_t i = 0; i < tokens.size(); i++)
        if(tokens[i].compare(token) == 0) return i;
    return -1;
}

void execute(std::vector<std::string> &tokens)
{
    char * argv[tokens.size()+1];
    argv[tokens.size()]=NULL;
    for (std::size_t i = 0; i < tokens.size(); ++i)
    {
        argv[i] = &tokens[i][0];
    }
    int res= execvp(argv[0],argv);
    if(res == -1) perror("shell");
}

void pipeline(std::vector<std::string> tokens, bool background)
{
    //done just fix & and make if on background
    int READ_END = 0;
    int WRITE_END = 1;

    int STDIN = 0;
    int STDOUT = 1;

    if(tokens[tokens.size() -1] == "&")
    {
        tokens.pop_back();
    }

    std::string file1 = "";
    std::string file2 = "";
    bool append = false;

    //Get I/O redirection filenames, if there are any
    for(size_t i=0; i<tokens.size(); i++) {
        if(tokens[i] == "<") file1 = tokens[i+1];
        else if(tokens[i] == ">>") {
            file2 = tokens[i+1];
            append = true;
        }
        else if(tokens[i] == ">") file2 = tokens[i+1];
    }

    std::string pipeSym = "|";
    size_t pipePos = findToken(tokens,pipeSym);
    if(pipePos == -1) return;

    //Get first and second command of pipeline
    std::vector<std::string> cmd1(tokens.begin(),tokens.begin() + pipePos);
    std::vector<std::string> cmd2(tokens.begin() + pipePos + 1, tokens.end());

    if(file1 != "") {
        //Discard < and filename
        cmd1.pop_back();
        cmd1.pop_back();
    }

    if(file2 != "") {
        //Discard >|>> and filename
        cmd2.pop_back();
        cmd2.pop_back();
    }

    int fd[2];
    if(pipe(fd) < 0) cout << "Pipe Error" << endl;

    pid_t childpid = fork();
    if(childpid == -1) cout << "Fork Error" << endl;

    if(childpid == 0)
    {
        if(file1 != "") {
            //Open input file for first command
            int rFile = open( file1.c_str(), O_RDONLY);
            if(rFile == -1) {
                perror(file1.c_str());
                _exit(0);
            }
            dup2(rFile,STDIN);
            close(rFile);
        }
        dup2(fd[WRITE_END],STDOUT); //Point writing end to STDOUT
        close(fd[READ_END]);
        execute(cmd1);
        _exit(0);
    }

    else
    {
        int status;
        if(background)
        {
            //Stop the child process and add it to pidlist for round robin
            //If the list is empty then start the timer for round robin
            kill(childpid,SIGSTOP);
            if (pidlist.empty())
            {
                start_timer();
            }
            pidlist.push_back(childpid);
        }

        close(fd[WRITE_END]); //Close writing end

        pid_t childpid_2 = fork();

        if(childpid_2 == 0)
        {
            if(file2 != "") {
                int wFile;
                if(append) wFile = open(file2.c_str(), O_WRONLY | O_CREAT | O_APPEND, S_IRUSR | S_IWUSR);
                else wFile = open(file2.c_str(), O_WRONLY | O_CREAT | O_TRUNC, S_IRUSR | S_IWUSR);
                if(wFile == -1) {
                    perror(file2.c_str());
                    _exit(0);
                }
                dup2(wFile,STDOUT);
                close(wFile);
            }
            dup2(fd[READ_END],STDIN); //Point reading end to STDIN
            close(fd[READ_END]);
            execute(cmd2);
            _exit(0);
        }
        else
        {
            if(background)
            {
                kill(childpid_2,SIGSTOP);
                if (pidlist.empty())
                {
                    start_timer();
                }
                pidlist.push_back(childpid_2);
            }
        }
        if(!background) {
            waitpid(childpid,&status,0);
            waitpid(childpid_2,&status,0);
        }

    }
    close(fd[WRITE_END]);
    close(fd[READ_END]);
}


void doIO(std::vector<std::string> &tokens,std::vector<std::string> &iocommands)
{
    fflush(0);
    bool runBack = false;
    bool error = false;
    pid_t forked;
    std::string fileName = (iocommands[1]);

    size_t runBackground = iocommands[1].find("&");
    if(runBackground!=std::string::npos)
    {
        runBack = true;
        fileName = fileName.substr(0,runBackground);
    }
    fileName = trim(fileName);
    if(iocommands[2]=="<")
    {
        std::string file1 = ("");
        std::string file2 = ("");
        bool hasOutputAppend = false;
        bool hasOutputCreate = false;
        std::string comm = fileName;
        size_t found = comm.find(">>");
        if(found!=std::string::npos)
        {
            file1 = comm.substr(0, found);
            if(file1.length()>0)
            {
                file1 = trim(file1);
            }
            file2 = comm.substr(found+2, comm.size()-1);
            if(file2.length()>0)
            {
                file2 = trim(file2);
            }
            hasOutputAppend = true;
        }
        if(!hasOutputAppend)
        {
            size_t found = comm.find(">");
            if(found!=std::string::npos)
            {
                file1 = comm.substr(0, found);
                if(file1.length()>0)
                {
                    file1 = trim(file1);
                }
                file2 = comm.substr(found+1, comm.size()-1);
                if(file2.length()>0)
                {
                    file2 = trim(file2);
                }
                hasOutputCreate = true;
            }
        }
        if(!hasOutputAppend && !hasOutputCreate)
        {
            forked = fork();
            if(forked == 0)
            {
                int fd = 0;
                fd = open( fileName.c_str(), O_RDONLY);
                dup2(fd, 0);
                close(fd);
                if(fd!=-1)  execute(tokens);
                else    cout<<"No such file or directory"<<endl;
            }
            if(!runBack)
            {
                int status;
                waitpid(forked, &status, 0);
            }
            else
            {
                kill(forked,SIGSTOP);
                if (pidlist.empty())
                {
                    start_timer();
                }
                pidlist.push_back(forked);
            }
        }
        else if(hasOutputAppend)
        {
            forked = fork();
            if(forked == 0)
            {
                int fd = 0;
                fd = open( file1.c_str(), O_RDONLY);
                dup2(fd, 0);
                close(fd);

                //redirect output to file b
                if(fd!=-1)
                {
                    int fd1 = open(file2.c_str(), O_WRONLY | O_CREAT | O_APPEND, S_IRUSR | S_IWUSR);

                    dup2(fd1, 1);

                    close(fd1);

                    execute(tokens);
                }
                else    cout<<"No such file or directory"<<endl;
            }
            if(!runBack)
            {
                int status;
                waitpid(forked, &status, 0);
            }
            else
            {
                kill(forked,SIGSTOP);
                if (pidlist.empty())
                {
                    start_timer();
                }
                pidlist.push_back(forked);
            }
        }
        else if(hasOutputCreate)
        {
            forked = fork();
            if(forked == 0)
            {
                int fd = 0;
                fd = open( file1.c_str(), O_RDONLY);
                dup2(fd, 0);
                close(fd);

                //redirect output to file b
                if(fd!=-1)
                {
                    int fd1 = open(file2.c_str(), O_WRONLY | O_CREAT | O_TRUNC, S_IRUSR | S_IWUSR);

                    dup2(fd1, 1);

                    close(fd1);
                    execute(tokens);
                }
                else    cout<<"No such file or directory"<<endl;
            }
            if(!runBack)
            {
                int status;
                waitpid(forked, &status, 0);
            }
            else
            {
                kill(forked,SIGSTOP);
                if (pidlist.empty())
                {
                    start_timer();
                }
                pidlist.push_back(forked);
            }
        }
    }
    else if(iocommands[2]==">>")//append sto arxeio
    {
        forked = fork();
        if(forked == 0)
        {
            int fd = open(fileName.c_str(), O_WRONLY | O_CREAT | O_APPEND, S_IRUSR | S_IWUSR);

            dup2(fd, 1);

            close(fd);
            execute(tokens);
        }
        if(!runBack)
        {
            int status;
            waitpid(forked, &status, 0);
        }
        else
        {
            kill(forked,SIGSTOP);
            if (pidlist.empty())
            {
                start_timer();
            }
            pidlist.push_back(forked);
        }
    }
    else if(iocommands[2]==">")//svhsimo paliou kai grapsimo kainourgiou
    {
        pid_t forked = fork();
        if(forked == 0)
        {
            int fd = open(fileName.c_str(), O_WRONLY | O_CREAT | O_TRUNC, S_IRUSR | S_IWUSR);

            dup2(fd, 1);

            close(fd);
            execute(tokens);
        }
        if(!runBack)
        {
            int status;
            waitpid(forked, &status, 0);
        }
        else
        {
            kill(forked,SIGSTOP);
            if (pidlist.empty())
            {
                start_timer();
            }
            pidlist.push_back(forked);
        }
    }
}

std::vector<std::string> getIOcommands(std::string command)
{
    std::vector<std::string> iocommands;
    if(command.length()==0)
    {
        command = " ";
        iocommands.push_back(command);
        return iocommands;
    }
    command = trim(command);

    std::vector<std::string> symbols;
    symbols.push_back("<");
    symbols.push_back(">>");
    symbols.push_back(">");

    for(std::size_t i=0; i<symbols.size(); i++)
    {
        std::vector<std::string> iocommands;
        size_t found = command.find(symbols[i]);
        if(found!=std::string::npos)
        {
            std::string commandPart = ("");
            std::string fileName = ("");
            commandPart = command.substr(0, found);
            if(commandPart.length()>0)
            {
                commandPart = trim(commandPart);
            }
            fileName = command.substr(found+symbols[i].length(), command.size()-1);
            if(fileName.length()>0)
            {
                fileName = trim(fileName);
            }
            iocommands.push_back(commandPart);
            iocommands.push_back(fileName);
            iocommands.push_back(symbols[i]);
            return iocommands;
        }
    }
    iocommands.push_back(command);
    return iocommands;
}




int main()
{
    bool done = false;
    bool background,pipe,io;

    std::string command;
    std::vector<std::string> tokens;
    signal(SIGINT,signal_handler);
    //Buffer to store current directory
    size_t bufLen = 1024;
    char path[bufLen];

    while(!done)
    {
        background = false;
        pipe = false;
        io = false;

        //Get current directory
        getcwd(path,bufLen);

        cout << "Shell: "<< path << "$ ";

        std::getline(cin,command);
        std::vector<std::string> iocommands;
        iocommands = getIOcommands(command);
        if(iocommands.size()>1)
        {
            //Yparxei I/O command
            io = true;
        }
        //iocommands[0] == commandPart
        tokens = getTokens(command);

        if (trim(command)!="")
        {
            if(tokens[tokens.size()-1]=="&") background = true;
            if(findToken(tokens,"|") != -1) pipe = true;

            //If there is io redirection and pipeline,
            //then io redirection happens at pipeline function
            if(io && pipe) io = false;

            if(tokens[0] == "cd")
            {
                int res = chdir(tokens[tokens.size()-1].c_str());
                if(res == -1) perror("chdir");
            }
            else if(tokens[0] == "exit")
            {
                done = true;
                raise(SIGINT);
            }
            else if(pipe) pipeline(tokens,background);
            else if(io) {
                //Edo IO Redirection
                command = iocommands[0];
                tokens = getTokens(command);
                doIO(tokens,iocommands);
            }
            else forkAndExecute(tokens,background);
        }
    }

    return 0;
}
